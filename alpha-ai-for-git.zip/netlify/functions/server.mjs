// Netlify Function that runs the whole Alpha AI server (pages + /api/chat + /api/health).
// It wraps the portable server bundle produced by `npm run build` (dist/server).
// Static files in dist/client are served directly by Netlify's CDN first.
import server from "../../dist/server/index.mjs";

export default async (request, context) =>
  server.fetch(request, process.env, {
    waitUntil: (p) => context?.waitUntil?.(p),
    passThroughOnException() {},
  });

export const config = { path: "/*", preferStatic: true };
