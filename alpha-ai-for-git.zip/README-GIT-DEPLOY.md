# Alpha AI — GitHub + Netlify (recommended)

This folder is the FULL source code. Use this for a real working tutor.

## 1. Upload to GitHub
1. Go to https://github.com and sign in
2. Click New repository → name it alpha-ai → Create
3. Click "uploading an existing file"
4. Drag ALL files from this folder into the page
5. Click Commit changes

## 2. Connect Netlify
1. Go to https://app.netlify.com and sign in
2. Add new site → Import an existing project
3. Choose GitHub → select alpha-ai
4. Build command: npm run build
5. Publish directory: dist/client
6. Click Deploy site and wait

## 3. Add your AI key
Site configuration → Environment variables → Add variable(s):

For Grok (xAI):
- AI_API_KEY = your key from https://console.x.ai
- AI_BASE_URL = https://api.x.ai/v1
- AI_MODEL = grok-2-latest

Or for Lovable:
- LOVABLE_API_KEY = your Lovable key

Then: Deploys → Trigger deploy → Deploy site

## 4. Open the site
Use your Netlify URL. Try /sign-in or continue as guest.

See DEPLOY.md for more detail.
