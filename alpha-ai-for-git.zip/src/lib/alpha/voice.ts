import { useCallback, useEffect, useRef, useState } from "react";

type Rec = {
  lang: string; interimResults: boolean; continuous: boolean;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null; onend: (() => void) | null;
  start: () => void; stop: () => void;
};

function getCtor(): (new () => Rec) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

export function useDictation(onText: (t: string) => void) {
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const rec = useRef<Rec | null>(null);
  const cb = useRef(onText);
  cb.current = onText;

  useEffect(() => setSupported(!!getCtor()), []);
  useEffect(() => () => rec.current?.stop(), []);

  const toggle = useCallback(() => {
    if (listening) { rec.current?.stop(); return; }
    const C = getCtor();
    if (!C) return;
    const r = new C();
    r.lang = "en-UG"; r.interimResults = false; r.continuous = false;
    r.onresult = (e) => {
      const t = Array.from(e.results).map((x) => x[0]?.transcript ?? "").join(" ");
      if (t) cb.current(t);
    };
    r.onerror = (e) => setError(e.error === "not-allowed" ? "Microphone permission was denied." : "Voice input failed. Please type instead.");
    r.onend = () => setListening(false);
    rec.current = r;
    setError(null);
    try { r.start(); setListening(true); } catch { setError("Voice input could not start."); }
  }, [listening]);

  return { supported, listening, error, toggle };
}

export function speechSupported() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export function speak(text: string) {
  if (!speechSupported()) return false;
  window.speechSynthesis.cancel();
  const clean = text.replace(/\$\$?[^$]*\$\$?/g, " (formula) ").replace(/[#*_`>|]/g, "").slice(0, 4000);
  const u = new SpeechSynthesisUtterance(clean);
  u.lang = "en-GB";
  window.speechSynthesis.speak(u);
  return true;
}

export function stopSpeaking() {
  if (speechSupported()) window.speechSynthesis.cancel();
}
