import { cn } from "@/lib/utils";

/** Geometric A mark — no graduation cap. Cyan → sky blue gradient. */
export function AlphaMark({ className, decorative = false }: { className?: string; decorative?: boolean }) {
  return (
    <svg
      viewBox="0 0 64 64"
      className={cn("select-none", className)}
      aria-hidden={decorative ? true : undefined}
      role={decorative ? undefined : "img"}
      aria-label={decorative ? undefined : "Alpha AI"}
    >
      <defs>
        <linearGradient id="alphaA" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="55%" stopColor="#0EA5E9" />
          <stop offset="100%" stopColor="#0284C7" />
        </linearGradient>
      </defs>
      {/* Solid A without cap */}
      <path
        fill="url(#alphaA)"
        d="M32 6 L8 58 h11.5 l4.8-12.2 h15.4 L44.5 58 H56 L32 6 Zm0 18.5 4.2 10.6 h-8.4 L32 24.5 Z"
      />
    </svg>
  );
}

/** @deprecated name kept for drop-in compatibility — same as AlphaMark */
export function AlphaLogo({ className, decorative = false }: { className?: string; decorative?: boolean }) {
  return <AlphaMark className={className} decorative={decorative} />;
}

export function AlphaWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <AlphaMark decorative className="h-9 w-9 shrink-0" />
      <div className="leading-tight">
        <div className="font-display text-lg font-bold text-brand">Alpha AI</div>
        {!compact && <div className="text-xs text-muted-foreground">Your Friendly Tutor</div>}
      </div>
    </div>
  );
}
