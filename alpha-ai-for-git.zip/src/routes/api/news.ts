import { createFileRoute } from "@tanstack/react-router";

type Item = {
  id: string;
  title: string;
  body: string;
  date?: string;
  source: string;
  link: { label: string; href: string };
};

const OFFICIAL: Item[] = [
  {
    id: "uneb-portal",
    title: "UNEB official portal",
    body: "Registration, timetables, results and press releases.",
    source: "UNEB",
    link: { label: "uneb.ac.ug", href: "https://uneb.ac.ug" },
  },
  {
    id: "ncdc-portal",
    title: "NCDC curriculum resources",
    body: "Syllabi and competence-based curriculum materials.",
    source: "NCDC",
    link: { label: "ncdc.go.ug", href: "https://ncdc.go.ug" },
  },
  {
    id: "moes-portal",
    title: "Ministry of Education and Sports",
    body: "Education sector policy and announcements.",
    source: "MoES",
    link: { label: "education.go.ug", href: "https://www.education.go.ug" },
  },
];

/** Extract recent posts from UNEB homepage HTML (WordPress-style links). */
function parseUnebHtml(html: string): Item[] {
  const items: Item[] = [];
  // Match title links like href="https://uneb.ac.ug/2026/07/31/slug/"
  const re =
    /<a[^>]+href="(https?:\/\/uneb\.ac\.ug\/(\d{4})\/(\d{2})\/(\d{2})\/[^"]+)"[^>]*>([^<]{12,180})<\/a>/gi;
  const seen = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = re.exec(html)) && items.length < 12) {
    const href = m[1];
    const title = m[5].replace(/\s+/g, " ").trim();
    if (seen.has(href) || /read more/i.test(title)) continue;
    seen.add(href);
    const date = `${m[2]}-${m[3]}-${m[4]}`;
    items.push({
      id: href,
      title,
      body: `Official UNEB notice · ${date}`,
      date,
      source: "UNEB",
      link: { label: "Read on uneb.ac.ug", href },
    });
  }
  return items;
}

async function fetchUneb(): Promise<Item[]> {
  try {
    const r = await fetch("https://uneb.ac.ug/", {
      headers: {
        "User-Agent": "AlphaAI-EducationBot/1.0 (+https://alpha-ai.app; educational notices)",
        Accept: "text/html",
      },
      signal: AbortSignal.timeout(12000),
    });
    if (!r.ok) return [];
    const html = await r.text();
    return parseUnebHtml(html);
  } catch {
    return [];
  }
}

async function handleNews() {
  const live = await fetchUneb();
  const items = live.length ? [...live, ...OFFICIAL.filter((o) => o.source !== "UNEB")] : OFFICIAL;
  return Response.json(
    {
      ok: true,
      source: live.length ? "uneb.ac.ug" : "official-links",
      fetchedAt: new Date().toISOString(),
      items,
    },
    {
      headers: {
        "Cache-Control": "public, max-age=1800",
        "Content-Type": "application/json",
      },
    },
  );
}

export const Route = createFileRoute("/api/news")({
  server: { handlers: { GET: () => handleNews() } },
});
