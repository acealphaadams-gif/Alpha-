import { createFileRoute } from "@tanstack/react-router";

import { aiConfig } from "@/lib/ai/tutor.server";

// Reports only whether the tutor backend is configured. Never returns the key.
export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: () =>
        new Response(JSON.stringify({ configured: Boolean(aiConfig().apiKey) }), {
          headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
        }),
    },
  },
});
